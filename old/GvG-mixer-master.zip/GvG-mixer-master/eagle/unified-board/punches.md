# Mixer board punchlist
...

  * Source and create actual lytic caps.
  * same for lil ceramics.
  * a zillion standoffs
* solid power input
  * big power caps & tiny R's
  * molex or screwterm for power in?
* track down combo connnectors
* all panel components on REVERSE!

---

# Off board parts, don't forget 'em

* Mix send pots
  * 31vj401-f3
* IEC plug/switch/fuseholder
 * Epcos/tdk: B84776
* fuse?
* input jacks
  * NCJ6FI-S
* output jacks
  * NC3MD-lx
  * NYS-230
* knobs
* transformers
* foh kill
* send 1 monitors send 2 switch...
